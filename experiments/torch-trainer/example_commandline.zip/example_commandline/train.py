from dataset import get_dataset_vessmap_train
from torchtrainer.train import DefaultTrainer

class VesselTrainer(DefaultTrainer):

    def get_dataset(self, dataset_class, dataset_path, split_strategy, resize_size, 
                    augmentation_strategy, **dataset_params):
        
        if dataset_class == "vessmap_few":
            ds_train, ds_valid, *dataset_props = get_dataset_vessmap_train(dataset_path, split_strategy)
            class_weights, ignore_index, collate_fn = dataset_props        
        
        return ds_train, ds_valid, class_weights, ignore_index, collate_fn

if __name__ == "__main__":
    # This is required to run the script from the command line
    VesselTrainer().fit()